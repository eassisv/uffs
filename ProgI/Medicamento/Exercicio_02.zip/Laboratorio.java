public class Laboratorio{
	String nomeFantasia, razaoSocial, cnpj, inscricaoEstadual, endereco, telefone;

	public String getNomeFantasia(){
		return this.nomeFantasia;
	}
	public void setNomeFantasia(String nome){
		this.nomeFantasia = nome;
	}

	
}
