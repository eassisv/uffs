package com.blog;

public interface Evaluable {
	public void evaluate(int value);
}
