
<form class="form-points" id="form-npoints" action="index.php" method="post">
  <label>Valores de X e Y dos pontos</label>
  <?php for($i = 0;  $i < $num_points; $i++){ ?>
    <div>
      <label>x<?php echo "$i"; ?></label><input type="text" name="x<?php echo "$i"; ?>">
      <label>y<?php echo "$i"; ?></label><input type="text" name="y<?php echo "$i"; ?>">
    </div>
  <?php } ?>
  <label>Xs para interpolar</label>
  <?php for($i = 0;  $i < $num_xs; $i++){ ?>
    <div class="points">
      <label>x<?php echo "$i"; ?></label><input type="text" name="xs<?php echo "$i"; ?>">
    </div>
  <?php } ?>
  <div>
  <button form="form-npoints" type="submit">Interpolar!</button>
</div>
</form>
