<form class="form" method="post" id="form-points" action="index.php">
  <div>
  <label>Número de pontos: </label>
  <input type="number" name="num_points" value='2' min='2' max='50'>
  </div>
  <div>
  <label>Xs para interpolar: </label>
  <input type="number" name="num_xs" min='1' max='50' value='1'>
  </div>
  <div>
  <button form="form-points" type="submit">Ok!</button>
  </div>
</form>
