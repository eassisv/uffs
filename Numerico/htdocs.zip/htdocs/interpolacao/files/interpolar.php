<?php

$pxs = array(); $pys = array();
$xs = array();

for($i = 0, $j = 0, $k = 0; key($_POST) != 'xs0'; $i++, next($_POST))
  if($i % 2 == 0) $pxs[$j++] = (float)current($_POST);
  else $pys[$k++] = (float)current($_POST);

for($i = 0; current($_POST) != null; $i++, next($_POST))
  $xs[$i] = (float)current($_POST);

unset($_POST);

$num_points = sizeof($pxs);
$num_xs = sizeof($xs);

# -------------Lagrange----------------- #

$lys = array();

function L($j, $x){
  $t = 1.0;
  global $num_points;
  global $pxs;
  for($k = 0; $k < $num_points; $k++)
    if($k == $j) continue;
    else{
      $t = $t * (($x - $pxs[$k])/($pxs[$j] - $pxs[$k]));
    }
  return $t;
}

for($i = 0; $i < $num_xs; $i++){
  $t = 0.0;
  for($j = 0; $j < $num_points; $j++){
    $t = $t + $pys[$j] * L($j, $xs[$i]);

  }
  $lys[$i] = $t;
}

# ------------Newton Diferenças------------------ #

$k = array();
$difs = array();

for($i = 0; $i < sizeof($xs); $i++){
  $difs[$i] = array();
  foreach ($pxs as $j) {
    $difs[$i][] = $xs[$i] - $j;
  }
}

$prods = array();

for($i = 0; $i < sizeof($xs); $i++){
  $prods[$i] = array();
  $prods[$i][] = $difs[$i][0];
  for($j = 1; $j < sizeof($pxs); $j++)
    $prods[$i][$j] = $prods[$i][$j-1] * $difs[$i][$j];
}

foreach ($pys as $i){
  $k[] = array();
  $k[0][] = $i;
}

for($i = 1; $i < $num_points; $i++){
  for($j = 0; $j < $num_points - $i; $j++){
    $k[$i][$j] = ($k[$i-1][$j+1] - $k[$i-1][$j]) / ($pxs[$j+$i] - $pxs[$j]);
  }
}

$nys = [];

for($i = 0; $i < sizeof($xs); $i++){
  $nys[$i] = $k[0][0];
  for($j = 1; $j < sizeof($pxs); $j++)
    $nys[$i] += ($k[$j][0] * $prods[$i][$j-1]);
}

#--------------Divisões Finitas-------------#

$h = $pxs[1] - $pxs[0];
$possivel = true;
$zs = [];

for($i = 1; $i < sizeof($pxs) - 1 && $possivel == true; $i++)
	if($pxs[$i+1] - $pxs[$i] != $h)
		$possivel = false;

$delta = [];
$fys = [];

if($possivel == true){

	global $delta;
	global $zs;
	global $fys;

	foreach ($pys as $i){
	  $delta[] = array();
	  $delta[0][] = $i;
	}

	for($i = 1; $i < $num_points; $i++){
	  for($j = 0; $j < $num_points - $i; $j++){
		$delta[$i][$j] = ($delta[$i-1][$j+1] - $delta[$i-1][$j]);
	  }
	}

	$f = [];
  $f[0] = 1;
  for($i = 1; $i <= sizeof($pxs); $i++)
		$f[$i] = $f[$i-1] * $i;

	for($i = 0; $i < $num_points; $i++){
	  for($j = 0; $j < $num_points - $i; $j++){
		  $k[$i][$j] = ($delta[$i][$j] / ($f[$i]*($h**$i)));
	  }
	}

  for($i = 0; $i < sizeof($xs); $i++){
    $z[$i] = ($xs[$i] - $pxs[0]) / $h;
  }

  global $prods;

  for($i = 0; $i < sizeof($xs); $i++){
    $prods[$i][0] = $z[$i];
    for($j = 1; $j < sizeof($pxs); $j++)
      $prods[$i][$j] = $prods[$i][$j-1] * ($z[$i] - $j);
  }

  global $fys;
  for($i = 0; $i < sizeof($xs); $i++){
    $fys[$i] = $pys[0];
    for($j = 1; $j < sizeof($pxs); $j++)
      $fys[$i] += ($h**$j * $prods[$i][$j-1] * $k[$j][0]);
  }

}


?>
