<div class="resposta">
  <h1 style="text-align: center;">Método de Lagrange</h1>
  <?php
    $n = $num_points - 1;
    for($i = 0; $i < $num_xs; $i++){ ?>
      <h1>P<small><?php echo "$n"; ?></small>(<?php echo "$xs[$i]"; ?>) = <?php echo"$lys[$i]"; ?></h1>
  <?php } ?>
</div>
<hr>
<div class="resposta">
  <h1 style="text-align: center;">Método de Diferenças Divididas</h1>
  <?php
    for($i = 0; $i < $num_xs; $i++){ ?>
      <h1>P<small><?php echo "$n"; ?></small>(<?php echo "$xs[$i]"; ?>) = <?php echo"$nys[$i]"; ?></h1>
  <?php } ?>
</div>
<div>
<hr>
<div class="resposta">
  <h1 style="text-align: center;">Método de Diferenças Finitas</h1>
  <?php
    if(!$possivel)
      echo "<p>Não é possível resolver com diferenças finitas</p>";
    else
      for($i = 0; $i < $num_xs; $i++){ ?>
        <h1>P<small><?php echo "$n"; ?></small>(<?php echo "$xs[$i]"; ?>) = <?php echo"$fys[$i]"; ?></h1>
  <?php } ?>
</div>
<div>
  <form>
    <button type="submit" formaction="index.php">Voltar</button></a>
  </form>
</div>
