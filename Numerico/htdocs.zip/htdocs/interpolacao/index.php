<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Interpolação</title>
  <style>
    div.form{
      align-items: stretch;
      background-color: #ccc;
      padding: 10px;
      margin: 10px auto;
      width: 450px;
      border-radius: 5px;
    }
    label{
      margin: 5px auto;
    }
    input{
      padding: 3px;
      margin: 10px;
      border-radius: 3px;
      border: 1px solid #bbb;
    }
    button{
      padding: 2px;
      margin: 10px;
      width: 80px;
    }
    h1{
      font-size: 12pt;
    }
  </style>
</head>
  <div class="form">
    <?php
      if(array_key_exists('num_points', $_POST)){
        $num_points = (int)$_POST['num_points'];
        $num_xs = (int)$_POST['num_xs'];
        include('files/form_points.php');
    ?>

    <?php
      }else{
        if($_POST == null) include('files/form_npoints.php');
        else{
          include('files/interpolar.php');
          include('files/resposta.php');
        }
      }
    ?>
  </div>
</html>
